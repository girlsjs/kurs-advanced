function addPostToHTML(post) {

}